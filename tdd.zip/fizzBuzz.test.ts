import fizzBuzz, {
  ruleA,
  ruleB,
  transferA,
  transferB,
  transferC,
  transferNumber,
} from './fizzBuzz';

test('test fizzBuzz', () => {
  const str = fizzBuzz([1, 5]);
  expect(str).toBe('12Fizz4Buzz');
});

test('rule a', () => {
  expect(ruleA(1)).toBe(false);
  expect(ruleA(3)).toBe(true);
});

test('rule b', () => {
  expect(ruleB(1)).toBe(false);
  expect(ruleB(5)).toBe(true);
});

test('transferA', () => {
  expect(transferA(1)).toBe(1);
  expect(transferA(3)).toBe(3);
  expect(transferA(5)).toBe(5);
  expect(transferA(15)).toBe('FizzBuzz');
});

test('transferB', () => {
  expect(transferB(1)).toBe(1);
  expect(transferB(3)).toBe('Fizz');
  expect(transferB(5)).toBe(5);
  expect(transferB(15)).toBe('Fizz');
});

test('transferC', () => {
  expect(transferC(1)).toBe(1);
  expect(transferC(3)).toBe(3);
  expect(transferC(5)).toBe('Buzz');
  expect(transferC(15)).toBe('Buzz');
});

test('transferNumber', () => {
  expect(transferNumber(1, [transferA, transferB, transferC])).toBe(1);
  expect(transferNumber(3, [transferA, transferB, transferC])).toBe('Fizz');
  expect(transferNumber(15, [transferA, transferB, transferC])).toBe(
    'FizzBuzz',
  );
  expect(transferNumber(5, [transferA, transferB, transferC])).toBe('Buzz');
});
